import { randomUUID } from 'crypto'
import bcrypt from 'bcryptjs'
import { ensureDataDirs } from './paths.js'
import { openDatabase } from './dbFactory.js'

ensureDataDirs()

const db = openDatabase()

function tableExists(name) {
  const row = db.prepare("select name from sqlite_master where type='table' and name=?").get(name)
  return !!row
}

function columnExists(table, col) {
  if (!tableExists(table)) return false
  return db.prepare(`pragma table_info(${table})`).all().some((c) => c.name === col)
}

function migrateDb() {
  if (!tableExists('borrowers')) return
  const borrowerCols = db.prepare('pragma table_info(borrowers)').all().map((c) => c.name)
  if (!borrowerCols.includes('loandisk_id')) {
    db.exec('alter table borrowers add column loandisk_id text')
    db.exec('create unique index if not exists idx_borrowers_loandisk on borrowers(loandisk_id)')
  }
  for (const col of ['first_name', 'last_name', 'branch_id', 'branch_name']) {
    if (!borrowerCols.includes(col)) db.exec(`alter table borrowers add column ${col} text`)
  }
  if (tableExists('transactions') && !columnExists('transactions', 'source_document_id')) {
    db.exec('alter table transactions add column source_document_id text references documents(id)')
    db.exec('create index if not exists idx_transactions_document on transactions(source_document_id)')
  }
  if (tableExists('loans') && !columnExists('loans', 'emi')) {
    db.exec('alter table loans add column emi real')
  }
}

export function resetAppData() {
  db.exec(`
    delete from exceptions;
    delete from transactions;
    delete from documents;
    delete from loans;
    delete from borrowers;
    delete from audit_log;
  `)
}

export function initDb() {
  db.exec(`
    create table if not exists users (
      id text primary key,
      email text unique not null,
      password_hash text not null,
      role text not null default 'collections',
      full_name text,
      created_at text default (datetime('now'))
    );

    create table if not exists borrowers (
      id text primary key,
      full_name text not null,
      aliases text,
      employer text,
      created_at text default (datetime('now'))
    );

    create table if not exists loans (
      id text primary key,
      borrower_id text references borrowers(id),
      loan_number text unique not null,
      outstanding_balance real,
      status text default 'active',
      created_at text default (datetime('now'))
    );

    create table if not exists transactions (
      id text primary key,
      date text not null,
      payer text,
      description text,
      amount real not null,
      reference text,
      status text default 'pending' check (status in ('pending','matched','exception','posted')),
      confidence_score real,
      matched_borrower_id text references borrowers(id),
      loan_id text references loans(id),
      import_hash text unique,
      created_at text default (datetime('now'))
    );

    create table if not exists exceptions (
      id text primary key,
      transaction_id text references transactions(id),
      type text check (type in ('unmatched','duplicate','partial','suspicious')),
      assigned_to text,
      sla_hours integer default 24,
      status text default 'open' check (status in ('open','resolved','escalated')),
      resolution_note text,
      created_at text default (datetime('now')),
      resolved_at text
    );

    create table if not exists audit_log (
      id text primary key,
      entity text,
      entity_id text,
      action text,
      actor text,
      prior_value text,
      new_value text,
      created_at text default (datetime('now'))
    );

    create table if not exists app_settings (
      key text primary key,
      value text not null
    );

    create table if not exists documents (
      id text primary key,
      filename text not null,
      mime_type text,
      size_bytes integer,
      storage_path text not null,
      uploaded_by text,
      document_type text,
      row_count integer default 0,
      created_at text default (datetime('now'))
    );

    create index if not exists idx_transactions_status on transactions(status);
    create index if not exists idx_transactions_date on transactions(date);
    create index if not exists idx_exceptions_status on exceptions(status);
  `)

  migrateDb()

  // Single admin login. The old demo account is removed so its credentials stop working.
  db.prepare("delete from users where email = 'demo@smartrepay.local'").run()
  const admin = db.prepare('select id from users where email = ?').get('admin@pbshope.com')
  if (!admin) {
    db.prepare(
      'insert into users (id, email, password_hash, role, full_name) values (?, ?, ?, ?, ?)'
    ).run(randomUUID(), 'admin@pbshope.com', bcrypt.hashSync('pbs2026', 10), 'system_owner', 'Admin')
  }

  const settingsCount = db.prepare('select count(*) as c from app_settings').get().c
  if (settingsCount === 0) {
    const defaults = {
      autoApproveThreshold: 80,
      autoEscalateOnBreach: true,
      slaHours: { unmatched: 24, duplicate: 4, partial: 24, suspicious: 72 },
      matchingRules: null,
    }
    db.prepare('insert into app_settings (key, value) values (?, ?)').run('global', JSON.stringify(defaults))
  }

  if (process.env.RESET_APP_DATA === 'true') {
    resetAppData()
    console.log('RESET_APP_DATA: cleared transactions, borrowers, loans, exceptions, and audit log')
  }
}

export function parseJson(val) {
  if (!val) return null
  try {
    return JSON.parse(val)
  } catch {
    return null
  }
}

export function rowBorrower(r) {
  if (!r) return null
  return {
    ...r,
    aliases: parseJson(r.aliases) || [],
    loandisk_id: r.loandisk_id || null,
    first_name: r.first_name || null,
    last_name: r.last_name || null,
    branch_id: r.branch_id || null,
    branch_name: r.branch_name || null,
  }
}

export default db
